const express = require('express');

const morgan = require('morgan')
const mongoose = require('mongoose')
const appRoutes = require('./routes/todoRoutes.js');
const TodoTask = require("./model/todo.js");
const dotenv = require('dotenv');
dotenv.config();

const app = express();

app.set('view engine', 'ejs');
app.set('views')

app.use("/static", express.static("public"));
app.use(express.urlencoded({ extended: true }));
app.use(morgan('dev'));

const dbURI = "mongodb+srv://netninja:Test1234@cluster0.l8cl3br.mongodb.net/TODO?retryWrites=true&w=majority";
mongoose.connect(dbURI).then((result) => app.listen(3000))
    .catch((err) => console.log(err));


app.use((req, res, next) => {
    res.locals.path = req.path;
    next();
});

//POST METHOD
// app.post('/', async (req, res) => {
//     const todoTask = new TodoTask({
//         content: req.body.content
//     });
//     try {
//         await todoTask.save();
//         res.redirect("/");
//     } catch (err) {
//         console.log(err)
//     }
// });

// GET METHOD
// app.get("/", async(req, res) => {
//     const tasks=await TodoTask.find({})
//     if(tasks){
//         res.render("index.ejs", { todoTasks: tasks });
//     }else{
//         console.log(err)
//     }
//  });

//UPDATE

// app.route("/edit/:id").get(async (req, res) => {
//     const id = req.params.id;
//     const tasks = TodoTask.findByIdAndUpdate({ id })
//     if (tasks) {
//         console.log(tasks);
//         res.render("todoEdit.ejs", { todoTasks: tasks, idTask: id });
//     } else {
//         console.log("Before Update Error")
//     }
// })
//     .post(async (req, res) => {
//         const id = req.params.id;
//         // const tasks = TodoTask.findByIdAndUpdate({id})
//         if (id) {
//             { _id: req.params.id }
//             {
//                 $set: {
//                     { content: req.body.content }
//                 }
//             }
//             res.render("todoEdit.ejs", { todoTasks: tasks });
//             res.redirect("/");
//         } else {
//             console.log(err)
//         }
//     });

//DELETE
// app.route("/remove/:id").get((req, res) => {
//     const id = req.params.id;
//     TodoTask.findByIdAndRemove(id)
//         .then(result => {
//             res.redirect('/');
//         })
//         .catch(err => {
//             console.log(err);
//         });
// });
