const todo = require("../model/todo");

const todo_list = async (req, res) => {
    const tasks = await TodoTask.find({})
    if (tasks) {
        res.render("index.ejs", { todoTasks: tasks });
    } else {
        console.log(err)
    }
};

const todo_save = async (req, res) => {
    const todoTask = new TodoTask({
        content: req.body.content
    });
    try {
        await todoTask.save();
        res.redirect("/");
    } catch (err) {
        console.log(err)
    }
};

const todo_delete = ((req, res) => {
    const id = req.params.id;
    TodoTask.findByIdAndRemove(id)
        .then(result => {
            res.redirect('/');
        })
        .catch(err => {
            console.log(err);
        });
});

const todo_update = (req, res) => {
    const id = req.params.id;
    const tasks = TodoTask.findByIdAndUpdate({ id })
    if (tasks) {
        console.log(tasks);
        res.render("todoEdit.ejs", { todoTasks: tasks, idTask: id });
    } else {
        console.log("Before Update Error")
    }
}
    post(async (req, res) => {
        const id = req.params.id;
        const tasks = TodoTask.findByIdAndUpdate({id})
        if (id) {
            { _id: req.params.id }
            {
                $set: {
                    { content: req.body.content }
                }
            }
            res.render("todoEdit.ejs", { todoTasks: tasks });
            res.redirect("/");
        } else {
            console.log(err)
        }
    });

module.exports = {
    todo_list,
    todo_save,
    todo_delete,
    todo_update
}