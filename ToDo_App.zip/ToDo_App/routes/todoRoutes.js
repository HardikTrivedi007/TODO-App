const express = require('express');
const todoController = require("../controller/todoController")
const router = express.Router();

router.get('/', todoController.todo_list);
router.post('/', todoController,todoController.todo_save);
router.delete('/remove/:id', todoController.todo_delete);
router.put('/edit/:id', todoController.todo_update);

module.exports=router;